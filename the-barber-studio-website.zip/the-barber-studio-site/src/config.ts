/**
 * ONE PLACE TO EDIT THE BUSINESS AND BOOKINGS.
 * Empty booking values intentionally show a booking placeholder rather than a broken form.
 * Put official Booksy Biz widget code in embedHtml OR a provider-approved iframe URL in iframeUrl.
 * If a provider only supports hosted booking, use bookingUrl instead.
 * Only paste trusted widget scripts obtained from the actual account owner.
 */
export type Booking = { embedHtml?: string; iframeUrl?: string; bookingUrl?: string };
export type Barber = {
  id: string;
  name: string;
  platform: 'Booksy' | 'Setmore' | 'Other';
  portrait?: string;
  booking: Booking;
};
export const shop = {
  name: 'The Barber Studio',
  tagline: 'QUALITY OVER QUANTITY. CUSTOMER SERVICE FIRST.',
  phone: '9562301550',
  displayPhone: '(956) 230-1550',
  address: '401 S 77 Sunshine Strip, Suite D, Harlingen, TX 78550',
  mapsUrl: 'https://www.google.com/maps/search/?api=1&query=401+S+77+Sunshine+Strip+Suite+D+Harlingen+TX+78550',
  facebookUrl: 'https://www.facebook.com/share/1FYNe7pM4K/',
  linktreeUrl: 'https://linktr.ee/thebarberstudio956',
  hours: [
    ['Monday – Thursday','9:00 AM – 6:00 PM'],
    ['Friday','9:00 AM – 7:00 PM'],
    ['Saturday','9:00 AM – 6:00 PM'],
    ['Sunday','Closed'],
  ],
};
export const barbers: Barber[] = [
  {id:'j-armando',name:'J Armando',platform:'Booksy',booking:{}},
  {id:'efrian',name:'Efrian',platform:'Booksy',booking:{}},
  {id:'eybard',name:'Eybard',platform:'Booksy',booking:{}},
  {id:'jay-torres',name:'Jay Torres',platform:'Booksy',booking:{}},
  {id:'hector',name:'Hector',platform:'Booksy',booking:{}},
  {id:'oscar-morales',name:'Oscar Morales',platform:'Booksy',booking:{}},
  {id:'jake-martinez',name:'Jake Martinez',platform:'Setmore',booking:{}},
];
// The shop's Linktree also contains an additional non-barber-specific WL Bookings link.
// Add it separately here after confirming its purpose; it is not presented as an eighth barber.
export const generalBooking: Booking = {};
