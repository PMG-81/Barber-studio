import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ArrowDownRight, ArrowRight, CalendarDays, Check, ChevronRight, Clock3, ExternalLink, Facebook, MapPin, Menu, Phone, Scissors, ShieldCheck, X } from 'lucide-react';
import {barbers, shop, type Barber} from './config';
import './styles.css';

function Monogram({small=false}:{small?:boolean}) {return <span className={'monogram'+(small?' small':'')} aria-hidden="true"><Scissors size={small?19:28} strokeWidth={1.75}/></span>}

/** Insert official widget HTML into a real DOM node. React innerHTML does not execute script tags.
 * Only use widget HTML supplied by the owner of the booking account (trusted source).
 */
function BookingEmbed({html}:{html:string}) {
  const target = useRef<HTMLDivElement>(null);
  useEffect(()=>{
    const el=target.current;
    if(!el) return;
    el.replaceChildren();
    const template=document.createElement('template');
    template.innerHTML=html;
    const nodes=Array.from(template.content.childNodes);
    for (const node of nodes) {
      if(node.nodeName.toLowerCase()==='script'){
        const old=node as HTMLScriptElement;
        const script=document.createElement('script');
        for(const attr of Array.from(old.attributes)) script.setAttribute(attr.name,attr.value);
        script.text=old.text;
        el.appendChild(script);
      }else el.appendChild(node.cloneNode(true));
    }
    return ()=>el.replaceChildren();
  },[html]);
  return <div ref={target} className="booking-embed"/>;
}

function BookingModal({barber,onClose}:{barber:Barber|null;onClose:()=>void}){
  useEffect(()=>{
    if(!barber) return;
    const before=document.body.style.overflow;
    document.body.style.overflow='hidden';
    const onKey=(event:KeyboardEvent)=>{if(event.key==='Escape')onClose()};
    document.addEventListener('keydown',onKey);
    return ()=>{document.body.style.overflow=before;document.removeEventListener('keydown',onKey)};
  },[barber,onClose]);
  if(!barber)return null;
  const {embedHtml,iframeUrl,bookingUrl}=barber.booking;
  return <div className="modal-backdrop" onMouseDown={(e)=>{if(e.target===e.currentTarget)onClose()}} role="presentation">
    <section className="booking-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <div className="modal-top"><div><div className="eyebrow">YOUR NEXT FRESH CUT</div><h2 id="modal-title">BOOK WITH <span>{barber.name.toUpperCase()}</span></h2></div><button className="close-btn" onClick={onClose} aria-label="Close booking"><X size={22}/></button></div>
      {embedHtml ? <BookingEmbed html={embedHtml}/> : iframeUrl ? <iframe className="booking-frame" src={iframeUrl} title={`${barber.name} booking`} allow="payment"/> : bookingUrl ? <div className="booking-empty"><CalendarDays size={40}/><h3>READY TO BOOK?</h3><p>{barber.name} uses {barber.platform}. Continue to the official booking page to choose your appointment.</p><a className="btn btn-gold" href={bookingUrl} target="_blank" rel="noopener noreferrer">CONTINUE TO BOOKING <ExternalLink size={18}/></a></div> : <div className="booking-empty"><div className="empty-symbol"><CalendarDays size={34} strokeWidth={1.4}/></div><div className="slot-label">BOOKING INTEGRATION SPACE</div><h3>COMING SOON.</h3><p>The booking area for <strong>{barber.name}</strong> is ready. Once their official {barber.platform} embed code is added, the scheduling interface will appear right here.</p><div className="placeholder-note"><ShieldCheck size={18}/><span>No fake booking form. Appointments will connect to the barber’s existing booking system.</span></div></div>}
    </section>
  </div>
}

function App(){
  const [menu,setMenu]=useState(false);
  const [selected,setSelected]=useState<Barber|null>(null);
  const closeMenu=()=>setMenu(false);
  return <>
    <div className="topline"><span>HARLINGEN, TEXAS</span><span className="topline-divider"/><span>GOOD CUTS. GOOD PEOPLE.</span></div>
    <header className="header"><a href="#home" className="brand" onClick={closeMenu}><Monogram/><span className="brandtext"><strong>THE BARBER</strong><em>STUDIO <i>956</i></em></span></a>
      <nav className={menu?'nav open':'nav'} aria-label="Main navigation"><a href="#about" onClick={closeMenu}>THE STUDIO</a><a href="#barbers" onClick={closeMenu}>OUR BARBERS</a><a href="#experience" onClick={closeMenu}>THE EXPERIENCE</a><a href="#visit" onClick={closeMenu}>FIND US</a></nav>
      <a className="nav-book" href="#barbers">BOOK A CUT <ArrowUpRightIcon/></a><button className="menu-btn" onClick={()=>setMenu(!menu)} aria-label={menu?'Close menu':'Open menu'}>{menu?<X/>:<Menu/>}</button>
    </header>
    <main>
      <section className="hero" id="home"><div className="hero-image"/><div className="hero-shade"/><div className="hero-mark">EST. HARLINGEN <span>✳</span> TEXAS</div><div className="hero-content"><div className="hero-kicker"><span className="gold-line"/> THE BARBER STUDIO · 956</div><h1>LOOK SHARP.<br/><span>FEEL</span> DIFFERENT.</h1><p>More than a haircut. A place for clean fades, fresh styles, and the kind of service that keeps you coming back.</p><div className="hero-actions"><a href="#barbers" className="btn btn-gold">FIND YOUR BARBER <ArrowRight size={19}/></a><a href="#about" className="text-link">EXPLORE THE STUDIO <ArrowDownRight size={18}/></a></div></div><div className="hero-edge"><span>SCROLL TO EXPLORE</span><span className="edge-line"/></div><div className="hero-counter">01 / 04</div></section>
      <div className="ticker" aria-label="Our values"><div className="ticker-track">{Array.from({length:2},(_,i)=><span key={i}>PRECISION CUTS <b>✳</b> GOOD ENERGY <b>✳</b> QUALITY OVER QUANTITY <b>✳</b> HARLINGEN, TEXAS <b>✳</b> CUSTOMER SERVICE FIRST <b>✳</b> </span>)}</div></div>
      <section className="about section-wrap" id="about"><div className="about-label"><span className="eyebrow">01 / THE STUDIO</span><span className="section-mini">WHO WE ARE</span></div><div className="about-main"><h2>BUILT ON <span>QUALITY.</span><br/>BACKED BY <span>CRAFT.</span></h2><div className="about-row"><p>At The Barber Studio, it's never just about the cut. We're about attention to detail, solid service, and making sure you leave the chair feeling your best. No shortcuts. No rushing. Just quality over quantity.</p><div className="about-stamp"><Scissors size={33} strokeWidth={1.3}/><span>THE<br/>BARBER<br/>STUDIO</span></div></div></div></section>
      <section className="team-section" id="barbers"><div className="team-top section-wrap"><div><div className="eyebrow">02 / THE CREW</div><h2>MEET YOUR <span>BARBERS.</span></h2><p>Everyone's got their go-to. Find yours and get your next cut on the calendar.</p></div><span className="team-count">07 <small>BARBERS</small></span></div><div className="team-grid section-wrap">{barbers.map((barber,index)=><article className="barber-card" key={barber.id}><div className="barber-visual"><div className="barber-card-no">{String(index+1).padStart(2,'0')}</div>{barber.portrait?<img src={barber.portrait} alt={barber.name} loading="lazy"/>:<><div className="abstract-rim"/><div className="barber-portrait-placeholder"><Scissors size={55} strokeWidth={.7}/><span>PORTRAIT<br/>COMING SOON</span></div></>}<div className="barber-overlay"/></div><div className="barber-info"><div><span className="card-subtitle">THE BARBER STUDIO / 956</span><h3>{barber.name.toUpperCase()}</h3></div><button className="card-book" onClick={()=>setSelected(barber)} aria-label={`Open booking for ${barber.name}`}><ArrowRight size={23}/></button></div><button className="card-footer" onClick={()=>setSelected(barber)}><span>BOOK WITH {barber.name.toUpperCase()}</span><span>EXPLORE <ChevronRight size={15}/></span></button></article>)}</div><div className="team-foot section-wrap"><span>YOUR CHAIR IS WAITING.</span><span>SELECT A BARBER TO VIEW BOOKING <ArrowDownRight size={17}/></span></div></section>
      <section className="statement" id="experience"><div className="statement-image"/><div className="statement-overlay"/><div className="statement-content"><div className="eyebrow">03 / THE EXPERIENCE</div><h2>IT'S NOT<br/>JUST A <span>HAIRCUT.</span></h2><p>It's the details. The conversation. The confidence that comes with walking out fresh.</p><a href="#barbers" className="btn btn-outline">GET IN THE CHAIR <ArrowRight size={19}/></a></div><div className="statement-side">QUALITY OVER QUANTITY — ALWAYS.</div></section>
      <section className="visit section-wrap" id="visit"><div className="visit-title"><div className="eyebrow">04 / PULL UP</div><h2>COME THROUGH<span>.</span></h2><p>Right here in Harlingen. Your next great cut is closer than you think.</p><a href={shop.mapsUrl} className="btn btn-gold" target="_blank" rel="noopener noreferrer">GET DIRECTIONS <ArrowRight size={19}/></a></div><div className="visit-details"><div className="detail-row"><MapPin size={21}/><div><span>LOCATION</span><p>{shop.address}</p><a href={shop.mapsUrl} target="_blank" rel="noopener noreferrer">OPEN MAP <ExternalLink size={13}/></a></div></div><div className="detail-row"><Phone size={21}/><div><span>GIVE US A CALL</span><p><a href={`tel:${shop.phone}`}>{shop.displayPhone}</a></p></div></div><div className="detail-row"><Clock3 size={21}/><div><span>STUDIO HOURS</span><div className="hours">{shop.hours.map(([day,hours])=><div key={day}><span>{day}</span><strong>{hours}</strong></div>)}</div><small>Hours may vary by barber; confirm before visiting.</small></div></div></div></section>
      <section className="bottom-cta"><div className="eyebrow">KEEP IT CLEAN. KEEP IT FRESH.</div><h2>YOUR NEXT CUT<br/>STARTS <span>HERE.</span></h2><a href="#barbers" className="btn btn-dark">CHOOSE YOUR BARBER <ArrowRight size={19}/></a></section>
    </main>
    <footer className="footer"><div className="footer-upper"><a className="brand" href="#home"><Monogram/><span className="brandtext"><strong>THE BARBER</strong><em>STUDIO <i>956</i></em></span></a><div><span>FOLLOW THE STUDIO</span><a href={shop.facebookUrl} target="_blank" rel="noopener noreferrer" aria-label="Facebook"><Facebook size={21}/></a></div></div><div className="footer-lower"><span>© {new Date().getFullYear()} THE BARBER STUDIO. ALL RIGHTS RESERVED.</span><span>HARLINGEN, TEXAS · 956</span><a href="#home">BACK TO TOP ↑</a></div></footer>
    <BookingModal barber={selected} onClose={()=>setSelected(null)}/>
  </>
}
function ArrowUpRightIcon(){return <ArrowRight size={18} style={{transform:'rotate(-45deg)'}}/>}
createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>);
