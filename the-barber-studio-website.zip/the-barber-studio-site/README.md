# The Barber Studio — Website

A responsive, custom-coded barbershop site for The Barber Studio in Harlingen, Texas. Built with React, TypeScript, Vite, and plain CSS. Designed to deploy directly on Vercel.

## Run locally

1. Install Node.js 20+.
2. Run `npm install`.
3. Run `npm run dev` and open the local address printed by Vite.
4. Run `npm run build` to build production files into `dist/`.

## Deploy: GitHub → Vercel

1. Create a GitHub repository and upload all project files (not the ZIP itself).
2. Import the repository in Vercel.
3. Vercel should auto-detect **Vite**. Build: `npm run build`; output directory: `dist`.
4. Deploy. The included `vercel.json` handles SPA routing.

## Edit barbers and booking connections

**All barber settings are in `src/config.ts`.** Each barber has a `booking` object, initially `{}` to intentionally display a polished placeholder. Pick ONE method for each barber:

### Booksy / Setmore official HTML widget

```ts
{
  id: 'j-armando',
  name: 'J Armando',
  platform: 'Booksy',
  booking: {
    embedHtml: `<div>PASTE OFFICIAL WIDGET HTML HERE</div>`
  }
}
```

The `BookingEmbed` React component mounts the HTML and re-creates its `<script>` tags so official provider widgets can run. **Only use trusted embed code obtained from that barber's booking account.** Check whether the specific widget supports the desired flow on mobile. Some widgets open a hosted booking page even when the launch button is on your site.

### Approved iframe widget

```ts
booking: { iframeUrl: 'https://PROVIDER-APPROVED-EMBED-URL' }
```

Use this only if the provider specifically supports iframe embedding. Many standard booking links reject iframe embeds with `X-Frame-Options` or CSP restrictions.

### Standard booking page fallback

```ts
booking: { bookingUrl: 'https://official-booking-page.example' }
```

The modal will show a clear 'Continue to booking' action instead of breaking. Do not insert a regular Booksy booking URL as an iframe unless Booksy expressly supports it.

## Profiles and images

- The seven barber names and booking provider labels came from the shop's public Linktree.
- Add photos you have permission to use in `public/images/` (e.g. `public/images/j-armando.jpg`). Set `portrait:'/images/j-armando.jpg'` in each barber's configuration.
- No AI-generated portraits of staff are included. Until supplied, each card displays a designed portrait placeholder.
- Replace the stock hero/experience images with **actual authorized shop photography** before presenting the website as a final representation of the business.
- Background images currently use externally hosted Unsplash images and require internet access. To self-host them, save a licensed image into `public/images/` and update `.hero-image` and `.statement-image` in `src/styles.css`.
- The wordmark is a custom typographic treatment, **not** the shop's official logo. Replace it with an authorized transparent logo if available.

## Verify before launch

- Confirm business hours with the owner. Public listings can be outdated.
- Confirm phone and address.
- Confirm barber roster, display names, and actual booking platform for each one.
- Obtain every provider's official widget code / correct booking URL.
- Get permission to use any official branding and images.
- Verify appointment creation and mobile booking on all seven booking providers.

## What works right now

Responsive navigation, scroll sections, seven barber cards, per-barber booking modal placeholders, support for HTML widgets / approved iframe widgets / direct URLs, click-to-call, directions, Facebook link, and mobile styling.

## What does not work until configured

Completing appointments. All seven booking objects intentionally start empty. Booking is not falsely advertised as operational. The separate general WL Bookings Linktree entry has not been assigned to a barber.
